package billing.repositories;

import billing.BillItem;

public interface BillItemRepository {
    void save(int billId, BillItem item);
}

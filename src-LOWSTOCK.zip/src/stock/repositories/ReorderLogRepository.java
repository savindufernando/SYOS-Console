package stock.repositories;

import java.util.List;

public interface ReorderLogRepository {
    void logReorder(String productCode, int qty);
    List<String> getAllLogs();

}

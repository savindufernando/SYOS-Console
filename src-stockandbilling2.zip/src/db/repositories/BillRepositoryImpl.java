package db.repositories;

import billing.Bill;
import billing.repositories.BillRepository;
import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillRepositoryImpl implements BillRepository {

    @Override
    public int save(Bill bill) {
        String sql = "INSERT INTO bills (user_id, bill_date, total_amount, cash_tendered, change_amount, transaction_type) " +
                "VALUES (?, NOW(), ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, bill.getUserId());
            ps.setDouble(2, bill.getTotalAmount());
            ps.setDouble(3, bill.getCashTendered());
            ps.setDouble(4, bill.getChangeAmount());
            ps.setString(5, bill.getTransactionType());   // ✅ save type
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }


    public Bill findById(int billId) {
        String sql = "SELECT * FROM bills WHERE bill_id=?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, billId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Bill bill = new Bill(
                        rs.getInt("user_id"),
                        "Cashier/Manager" // TODO: join users table for real name
                );
                bill.setBillId(rs.getInt("bill_id"));
                bill.finalizePayment(rs.getDouble("cash_tendered"));
                // restore total and change
                bill.addItem(null); // keep API happy if needed
                bill.getItems().clear(); // clear dummy
                billPrinterHydrate(bill, rs);
                return bill;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Bill> findRecent(int limit) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills ORDER BY bill_date DESC LIMIT ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Bill bill = new Bill(
                        rs.getInt("user_id"),
                        "Cashier/Manager"
                );
                bill.setBillId(rs.getInt("bill_id"));
                bill.finalizePayment(rs.getDouble("cash_tendered"));
                billPrinterHydrate(bill, rs);
                list.add(bill);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // helper to populate bill details properly
    private void billPrinterHydrate(Bill bill, ResultSet rs) throws SQLException {
        // we can’t reset totalAmount directly since it's managed in Bill
        // so either adjust Bill with setters or extend Bill entity
        // For now just print reference data
        System.out.println("Hydrated Bill #" + bill.getBillId() +
                " | Total=" + rs.getDouble("total_amount") +
                " | Cash=" + rs.getDouble("cash_tendered") +
                " | Change=" + rs.getDouble("change_amount"));
    }
}

package billing;

import stock.Product;

public class BillItem {
    private Product product;
    private int quantity;
    private double lineTotal;

    public BillItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        this.lineTotal = product.getUnitPrice() * quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getLineTotal() { return lineTotal; }
}

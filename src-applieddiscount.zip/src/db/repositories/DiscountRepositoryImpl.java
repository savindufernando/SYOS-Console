package db.repositories;

import billing.strategy.DiscountPolicy;
import billing.strategy.FixedDiscount;
import billing.strategy.PercentageDiscount;
import billing.strategy.NoDiscount;
import billing.repositories.DiscountRepository;
import db.DatabaseConnection;
import stock.Product;

import java.sql.*;
import java.time.LocalDate;

public class DiscountRepositoryImpl implements DiscountRepository {

    @Override
    public DiscountPolicy findActiveDiscountForProduct(Product product) {
        String sql = "SELECT * FROM discounts_products " +
                "WHERE product_id=? AND status='ACTIVE' " +
                "AND discount_start <= CURDATE() AND discount_end >= CURDATE()";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, product.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String type = rs.getString("discount_type");
                double value = rs.getDouble("discount_value");

                if ("PERCENTAGE".equalsIgnoreCase(type)) {
                    return new PercentageDiscount(value);
                } else if ("AMOUNT".equalsIgnoreCase(type)) {
                    return new FixedDiscount(value);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new NoDiscount(); // default no discount
    }
}

package billing.strategy;

import billing.Bill;

public class PercentageDiscount implements DiscountPolicy {
    private final double percent;

    public PercentageDiscount(double percent) {
        this.percent = percent;
    }

    @Override
    public double applyDiscount(Bill bill) {
        return bill.getTotalAmount() * (1 - percent / 100.0);
    }
}

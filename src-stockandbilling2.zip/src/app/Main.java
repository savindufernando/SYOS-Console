package app;

import cli.LoginMenu;

public class Main {
    public static void main(String[] args) {
        // Start the application by showing login screen
        new LoginMenu().start();
    }
}

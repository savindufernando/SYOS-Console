package billing;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Bill {
    private int billId;
    private int userId;
    private String cashierName;
    private LocalDateTime billDate;
    private double totalAmount;
    private double cashTendered;
    private double changeAmount;
    private String transactionType = "COUNTER";   // ✅ default
    private final List<BillItem> items = new ArrayList<>();

    public Bill(int userId, String cashierName) {
        this.userId = userId;
        this.cashierName = cashierName;
        this.billDate = LocalDateTime.now();
    }

    public void addItem(BillItem item) {
        items.add(item);
        totalAmount += item.getLineTotal();
    }

    public void removeItem(BillItem item) {
        if (items.remove(item)) {
            totalAmount -= item.getLineTotal();
        }
    }

    public void finalizePayment(double cashTendered) {
        this.cashTendered = cashTendered;
        this.changeAmount = cashTendered - totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public void setCashTendered(double cashTendered) {
        this.cashTendered = cashTendered;
    }

    public void setChangeAmount(double changeAmount) {
        this.changeAmount = changeAmount;
    }


    // ✅ getters & setters
    public int getBillId() { return billId; }
    public void setBillId(int billId) { this.billId = billId; }
    public int getUserId() { return userId; }
    public String getCashierName() { return cashierName; }
    public LocalDateTime getBillDate() { return billDate; }
    public double getTotalAmount() { return totalAmount; }
    public double getCashTendered() { return cashTendered; }
    public double getChangeAmount() { return changeAmount; }
    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }
    public List<BillItem> getItems() { return items; }
}



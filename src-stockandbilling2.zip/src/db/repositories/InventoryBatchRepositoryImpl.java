package db.repositories;

import db.DatabaseConnection;
import stock.batch.InventoryBatch;
import stock.repositories.InventoryBatchRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryBatchRepositoryImpl implements InventoryBatchRepository {
    @Override
    public void save(InventoryBatch batch) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO inventory_batches (product_id, purchase_date, expiry_date, quantity) VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, batch.getProductId());
            ps.setDate(2, Date.valueOf(batch.getPurchaseDate()));
            ps.setDate(3, batch.getExpiryDate() != null ? Date.valueOf(batch.getExpiryDate()) : null);
            ps.setInt(4, batch.getQuantity());
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void update(InventoryBatch batch) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE inventory_batches SET quantity=? WHERE batch_id=?")) {
            ps.setInt(1, batch.getQuantity());
            ps.setInt(2, batch.getId());
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public List<InventoryBatch> findByProduct(int productId) {
        List<InventoryBatch> batches = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM inventory_batches WHERE product_id=?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                InventoryBatch b = new InventoryBatch();
                b.setId(rs.getInt("batch_id"));
                b.setProductId(rs.getInt("product_id"));
                b.setQuantity(rs.getInt("quantity"));
                b.setPurchaseDate(rs.getDate("purchase_date").toLocalDate());
                Date expiry = rs.getDate("expiry_date");
                if (expiry != null) b.setExpiryDate(expiry.toLocalDate());
                batches.add(b);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return batches;
    }
}

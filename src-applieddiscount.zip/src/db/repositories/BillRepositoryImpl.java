package db.repositories;

import billing.Bill;
import billing.repositories.BillRepository;
import db.DatabaseConnection;
import stock.Product;
import stock.NonPerishableProduct;
import billing.BillItem;
import billing.strategy.NoDiscount;
import billing.strategy.DiscountPolicy;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BillRepositoryImpl implements BillRepository {

    @Override
    public int save(Bill bill) {
        String sql = "INSERT INTO bills (user_id, bill_date, total_amount, cash_tendered, change_amount, transaction_type) " +
                "VALUES (?, NOW(), ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, bill.getUserId());
            ps.setDouble(2, bill.getTotalAmount());
            ps.setDouble(3, bill.getCashTendered());
            ps.setDouble(4, bill.getChangeAmount());
            ps.setString(5, bill.getTransactionType());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                bill.setBillId(id); // keep bill object in sync
                return id;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public Bill findById(int billId) {
        String sql = "SELECT * FROM bills WHERE bill_id=?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, billId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return hydrateBill(rs, conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Bill> findRecent(int limit) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills ORDER BY bill_date DESC LIMIT ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(hydrateBill(rs, conn));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Bill> findByDate(LocalDate date) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills WHERE DATE(bill_date) = ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(date));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(hydrateBill(rs, conn));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Bill> findBetweenDates(LocalDate start, LocalDate end) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills WHERE DATE(bill_date) BETWEEN ? AND ?";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(start));
            ps.setDate(2, Date.valueOf(end));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(hydrateBill(rs, conn));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Bill> findAll() {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills";
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(hydrateBill(rs, conn));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // ✅ Hydrate Bill with amounts and items using the SAME connection
    private Bill hydrateBill(ResultSet rs, Connection conn) throws SQLException {
        Bill bill = new Bill(
                rs.getInt("user_id"),
                "Cashier/Manager" // TODO: join with users table
        );
        bill.setBillId(rs.getInt("bill_id"));
        bill.setTransactionType(rs.getString("transaction_type"));
        bill.setTotalAmount(rs.getDouble("total_amount"));
        bill.setCashTendered(rs.getDouble("cash_tendered"));
        bill.setChangeAmount(rs.getDouble("change_amount"));

        loadBillItems(bill, conn);

        return bill;
    }



    private void loadBillItems(Bill bill, Connection conn) throws SQLException {
        String sql = "SELECT bi.*, p.code, p.name, p.unit_price " +
                "FROM bill_items bi " +
                "JOIN products p ON bi.product_id = p.product_id " +
                "WHERE bi.bill_id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bill.getBillId());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String code = rs.getString("code");
                String name = rs.getString("name");
                double price = rs.getDouble("unit_price");
                int qty = rs.getInt("quantity");

                // Simplified: assume NonPerishable for now
                Product product = new NonPerishableProduct(code, name, price);
                product.setId(rs.getInt("product_id"));

                // ✅ Use NoDiscount for historical data
                DiscountPolicy discount = new NoDiscount();

                BillItem item = new BillItem(product, qty, discount);
                bill.addItem(item);
            }
        }
    }

}

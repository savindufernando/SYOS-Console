package billing.repositories;

import billing.Bill;

public interface BillRepository {
    int save(Bill bill);  // returns generated bill_id
}

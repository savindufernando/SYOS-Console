package billing;

import stock.Product;
import billing.strategy.DiscountPolicy;

public class BillItem {
    private Product product;
    private int quantity;
    private double lineTotal;
    private DiscountPolicy discount;

    // 🔹 Constructor with discount
    public BillItem(Product product, int quantity, DiscountPolicy discount) {
        this.product = product;
        this.quantity = quantity;
        this.discount = discount;

        double discountedPrice = discount.apply(product.getUnitPrice());
        this.lineTotal = discountedPrice * quantity;
    }

    // Getters
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getLineTotal() { return lineTotal; }
    public DiscountPolicy getDiscount() { return discount; }
}

package stock.repositories;

import stock.Product;

public interface ProductRepository {
    void save(Product product);
    Product findByCode(String code);

    void update(Product product);
}

package billing;

public class BillPrinter {
    public void print(Bill bill) {
        System.out.println("\n=== SYOS BILL #" + bill.getBillId() + " ===");
        System.out.println("Date: " + bill.getBillDate());
        System.out.println("Cashier: " + bill.getCashierName());

        for (BillItem item : bill.getItems()) {
            System.out.printf("%s x%d = %.2f\n",
                    item.getProduct().getName(),
                    item.getQuantity(),
                    item.getLineTotal());
        }

        System.out.println("----------------------------");
        System.out.printf("Total: %.2f\n", bill.getTotalAmount());
        System.out.printf("Cash Tendered: %.2f\n", bill.getCashTendered());
        System.out.printf("Change: %.2f\n", bill.getChangeAmount());
        System.out.println("============================");
    }
}

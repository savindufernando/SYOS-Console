package cli;

import db.repositories.ReorderLogRepositoryImpl;
import stock.repositories.ReorderLogRepository;

import java.util.List;
import java.util.Scanner;

public class ReorderLogMenu {
    private final ReorderLogRepository reorderLogRepo;
    private final Scanner scanner = new Scanner(System.in);

    public ReorderLogMenu() {
        this.reorderLogRepo = new ReorderLogRepositoryImpl();
    }

    public void start() {
        while (true) {
            System.out.println("\n=== Reorder Alerts ===");
            System.out.println("1. View All Alerts");
            System.out.println("0. Back");
            System.out.print("Choose option: ");

            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1 -> viewAllLogs();
                case 0 -> { return; }
                default -> System.out.println("❌ Invalid choice, try again.");
            }
        }
    }

    private void viewAllLogs() {
        List<String> logs = reorderLogRepo.getAllLogs();
        if (logs.isEmpty()) {
            System.out.println("✅ No reorder alerts found.");
        } else {
            System.out.println("⚠️ Reorder Alerts:");
            logs.forEach(System.out::println);
        }
    }
}

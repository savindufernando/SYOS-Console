package stock.repositories;

import stock.batch.ShelfBatch;
import java.util.List;

public interface ShelfBatchRepository {
    void save(ShelfBatch batch);
    void update(ShelfBatch batch);
    ShelfBatch findByProduct(int productId);
    List<ShelfBatch> findAll();

    // 🔹 New method with product details (batch + product info)
    List<ShelfBatch> findAllWithProducts();

    // 🔹 New method for billing: lookup shelf by product code
    ShelfBatch findByProductCode(String productCode);
}

package stock.repositories;

import stock.batch.ShelfBatch;
import java.util.List;

public interface ShelfBatchRepository {
    void save(ShelfBatch batch);
    void update(ShelfBatch batch);
    ShelfBatch findByProduct(int productId);
    List<ShelfBatch> findAll();

    // 🔹 New method with product details
    List<ShelfBatch> findAllWithProducts();
}

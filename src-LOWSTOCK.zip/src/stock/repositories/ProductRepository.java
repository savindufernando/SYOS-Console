package stock.repositories;

import stock.Product;

public interface ProductRepository {
    void save(Product product);
    Product findByCode(String code);
    Product findById(int id);     // ✅ added
    String findCodeById(int id);  // ✅ added
    void update(Product product);
}

package auth;

import db.repositories.UserRepository;

public class AuthService {
    private final UserRepository userRepo = new UserRepository();

    public User login(String username, String password) {
        return userRepo.findByUsernameAndPassword(username, password);
    }
}

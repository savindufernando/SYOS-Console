package db.repositories;

import db.DatabaseConnection;
import stock.repositories.ReorderLogRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReorderLogRepositoryImpl implements ReorderLogRepository {
    @Override
    public void logReorder(String productCode, int qty) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO reorder_log (product_code, current_qty) VALUES (?, ?)")) {
            ps.setString(1, productCode);
            ps.setInt(2, qty);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public List<String> getAllLogs() {
        List<String> logs = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getInstance();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM reorder_log ORDER BY log_date DESC")) {

            while (rs.next()) {
                String log = "LogID=" + rs.getInt("log_id") +
                        " | Product=" + rs.getString("product_code") +
                        " | Qty=" + rs.getInt("current_qty") +
                        " | Date=" + rs.getTimestamp("log_date");
                logs.add(log);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return logs;
    }
}

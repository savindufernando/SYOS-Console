package billing.strategy;

import billing.Bill;

public interface DiscountPolicy {
    double applyDiscount(Bill bill);
}

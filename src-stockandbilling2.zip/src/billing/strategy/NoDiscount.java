package billing.strategy;

import billing.Bill;

public class NoDiscount implements DiscountPolicy {
    @Override
    public double applyDiscount(Bill bill) {
        return bill.getTotalAmount(); // no change
    }
}

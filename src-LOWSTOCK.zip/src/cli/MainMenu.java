package cli;

import auth.User;
import db.repositories.InventoryBatchRepositoryImpl;
import db.repositories.ShelfBatchRepositoryImpl;
import db.repositories.OnlineBatchRepositoryImpl; // ✅ added

import java.util.Scanner;

public class MainMenu implements Menu {
    private final Scanner scanner = new Scanner(System.in);
    private final User loggedUser;

    public MainMenu(User loggedUser) {
        this.loggedUser = loggedUser;
    }

    @Override
    public void start() {
        while (true) {
            System.out.println("\n=== Main Menu (" + loggedUser.getRole() + ") ===");
            System.out.println("1. Checkout / Billing");
            if ("MANAGER".equalsIgnoreCase(loggedUser.getRole())) {
                System.out.println("2. Inventory Management");
                System.out.println("3. Shelf Management");
                System.out.println("4. Reorder Alerts");  // ✅ new
                System.out.println("5. Logout");
            }
            else {
                System.out.println("2. Logout");
            }
            System.out.print("Choose option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if ("MANAGER".equalsIgnoreCase(loggedUser.getRole())) {
                switch (choice) {
                    case 1 -> System.out.println("💳 Checkout Menu (Not implemented yet)");
                    case 2 -> new InventoryMenu(
                            new InventoryBatchRepositoryImpl(),
                            new ShelfBatchRepositoryImpl(),
                            new OnlineBatchRepositoryImpl() // ✅ added
                    ).start();
                    case 3 -> new ShelfMenu(
                            new ShelfBatchRepositoryImpl()
                    ).start();
                    case 4 -> new ReorderLogMenu().start();
                    case 5 -> {
                        System.out.println("👋 Logging out...");
                        return;
                    }
                    default -> System.out.println("❌ Invalid choice, try again.");
                }
            } else {
                switch (choice) {
                    case 1 -> System.out.println("💳 Checkout Menu (Not implemented yet)");
                    case 2 -> {
                        System.out.println("👋 Logging out...");
                        return;
                    }
                    default -> System.out.println("❌ Invalid choice, try again.");
                }
            }
        }
    }
}

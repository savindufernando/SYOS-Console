package db.repositories;

import db.DatabaseConnection;
import stock.batch.ShelfBatch;
import stock.repositories.ShelfBatchRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShelfBatchRepositoryImpl implements ShelfBatchRepository {
    @Override
    public void save(ShelfBatch batch) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO shelf_batches (product_id, quantity, last_restocked) VALUES (?, ?, ?)")) {
            ps.setInt(1, batch.getProductId());
            ps.setInt(2, batch.getQuantity());
            if (batch.getLastRestocked() != null) {
                ps.setDate(3, Date.valueOf(batch.getLastRestocked()));
            } else {
                ps.setNull(3, Types.DATE);
            }
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public void update(ShelfBatch batch) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE shelf_batches SET quantity=?, last_restocked=? WHERE shelf_batch_id=?")) {
            ps.setInt(1, batch.getQuantity());
            if (batch.getLastRestocked() != null) {
                ps.setDate(2, Date.valueOf(batch.getLastRestocked()));
            } else {
                ps.setNull(2, Types.DATE);
            }
            ps.setInt(3, batch.getId());
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    @Override
    public ShelfBatch findByProduct(int productId) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM shelf_batches WHERE product_id=?")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ShelfBatch b = new ShelfBatch();
                b.setId(rs.getInt("shelf_batch_id"));
                b.setProductId(rs.getInt("product_id"));
                b.setQuantity(rs.getInt("quantity"));
                Date d = rs.getDate("last_restocked");
                if (d != null) b.setLastRestocked(d.toLocalDate());
                return b;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    @Override
    public List<ShelfBatch> findAll() {
        List<ShelfBatch> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM shelf_batches")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ShelfBatch b = new ShelfBatch();
                b.setId(rs.getInt("shelf_batch_id"));
                b.setProductId(rs.getInt("product_id"));
                b.setQuantity(rs.getInt("quantity"));
                Date d = rs.getDate("last_restocked");
                if (d != null) b.setLastRestocked(d.toLocalDate());
                list.add(b);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    @Override
    public List<ShelfBatch> findAllWithProducts() {
        List<ShelfBatch> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT sb.shelf_batch_id, sb.product_id, sb.quantity, sb.last_restocked, " +
                             "       p.code AS product_code, p.name AS product_name " +
                             "FROM shelf_batches sb " +
                             "JOIN products p ON sb.product_id = p.product_id")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ShelfBatch b = new ShelfBatch();
                b.setId(rs.getInt("shelf_batch_id"));
                b.setProductId(rs.getInt("product_id"));
                b.setQuantity(rs.getInt("quantity"));
                Date d = rs.getDate("last_restocked");
                if (d != null) b.setLastRestocked(d.toLocalDate());

                // 🔹 extra info for reporting
                b.setProductCode(rs.getString("product_code"));
                b.setProductName(rs.getString("product_name"));

                list.add(b);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}

package stock.reorder;

import stock.repositories.ReorderLogRepository;

public class ReorderService implements ReorderObserver {
    private final ReorderLogRepository reorderLogRepo;

    public ReorderService(ReorderLogRepository reorderLogRepo) {
        this.reorderLogRepo = reorderLogRepo;
    }

    @Override
    public void notifyLowStock(String productCode, int currentQty) {
        System.out.println("📦 ALERT: Product " + productCode +
                " is low in inventory! Total left = " + currentQty);

        // ✅ Log into reorder_log table
        reorderLogRepo.logReorder(productCode, currentQty);
    }
}

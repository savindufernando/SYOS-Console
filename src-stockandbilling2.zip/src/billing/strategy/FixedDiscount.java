package billing.strategy;

import billing.Bill;

public class FixedDiscount implements DiscountPolicy {
    private final double amount;

    public FixedDiscount(double amount) {
        this.amount = amount;
    }

    @Override
    public double applyDiscount(Bill bill) {
        return Math.max(0, bill.getTotalAmount() - amount);
    }
}

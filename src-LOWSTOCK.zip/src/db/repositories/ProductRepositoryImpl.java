package db.repositories;

import db.DatabaseConnection;
import stock.Product;
import stock.PerishableProduct;
import stock.NonPerishableProduct;
import stock.repositories.ProductRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductRepositoryImpl implements ProductRepository {

    @Override
    public void save(Product product) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO products (product_code, product_name, product_type, unit_price) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, product.getCode());
            ps.setString(2, product.getName());
            ps.setString(3, product instanceof PerishableProduct ? "PERISHABLE" : "NONPERISHABLE");
            ps.setDouble(4, product.getUnitPrice());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Product findByCode(String code) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM products WHERE product_code=?")) {
            ps.setString(1, code);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapRowToProduct(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Product findById(int id) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM products WHERE product_id=?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapRowToProduct(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String findCodeById(int id) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement("SELECT product_code FROM products WHERE product_id=?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("product_code");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void update(Product product) {
        try (Connection conn = DatabaseConnection.getInstance();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE products SET product_code=?, product_name=?, product_type=?, unit_price=? WHERE product_id=?")) {
            ps.setString(1, product.getCode());
            ps.setString(2, product.getName());
            ps.setString(3, product instanceof PerishableProduct ? "PERISHABLE" : "NONPERISHABLE");
            ps.setDouble(4, product.getUnitPrice());
            ps.setInt(5, product.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ✅ helper to build correct subclass
    private Product mapRowToProduct(ResultSet rs) throws SQLException {
        String type = rs.getString("product_type");
        Product p;
        if ("PERISHABLE".equalsIgnoreCase(type)) {
            p = new PerishableProduct(
                    rs.getString("product_code"),
                    rs.getString("product_name"),
                    rs.getDouble("unit_price"),
                    null // expiry date can be handled if your table has it
            );
        } else {
            p = new NonPerishableProduct(
                    rs.getString("product_code"),
                    rs.getString("product_name"),
                    rs.getDouble("unit_price")
            );
        }
        p.setId(rs.getInt("product_id"));
        return p;
    }
}

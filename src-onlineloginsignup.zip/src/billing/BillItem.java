package billing;

import stock.Product;
import billing.strategy.DiscountPolicy;

public class BillItem {
    private Product product;
    private int quantity;
    private double lineTotal;
    private DiscountPolicy discount;
    private String discountName;
    private String discountType;   // "AMOUNT", "PERCENTAGE", or "NONE"
    private double discountValue;

    public BillItem(Product product, int quantity, DiscountPolicy discount) {
        this.product = product;
        this.quantity = quantity;
        this.discount = discount;

        // apply discount
        double discountedPrice = discount.apply(product.getUnitPrice());
        this.lineTotal = discountedPrice * quantity;

        // metadata
        this.discountName = discount.toString();
        if (discount instanceof billing.strategy.PercentageDiscount) {
            this.discountType = "PERCENTAGE";
            this.discountValue = ((billing.strategy.PercentageDiscount) discount).getPercent();
        } else if (discount instanceof billing.strategy.FixedDiscount) {
            this.discountType = "AMOUNT";
            this.discountValue = ((billing.strategy.FixedDiscount) discount).getAmount();
        } else {
            this.discountType = "NONE";
            this.discountValue = 0;
        }
    }

    // getters
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getLineTotal() { return lineTotal; }
    public DiscountPolicy getDiscount() { return discount; }
    public String getDiscountName() { return discountName; }
    public String getDiscountType() { return discountType; }
    public double getDiscountValue() { return discountValue; }
}
